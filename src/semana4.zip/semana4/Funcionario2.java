package semana4;

import java.util.ArrayList;
import java.util.Scanner;

public class Funcionario2 {

	static ArrayList<Estoque> lista = new ArrayList<Estoque>();
	static Scanner scan = new Scanner(System.in);

	public static void cadastrar() {

		System.out.println("Quantidade: ");
		int qtde = scan.nextInt();
		
		
		
		
		
		
	}
}

/**
 * int qtde, int id, Produto produto, String nome, int size, String cor, String
 * marca
 * 		System.out.println("Nome: ");
		(scan.next());
		
		System.out.println("Tamanho em cm: ");
		prod.setSize(scan.nextInt());
		
		System.out.println("Cor: ");
		prod.setCor(scan.next());
		
		System.out.println("Marca ");
		prod.setMarca(scan.next());
		
		lista.add(estoque);
 **/
