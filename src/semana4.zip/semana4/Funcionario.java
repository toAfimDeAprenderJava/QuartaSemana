package semana4;

public class Funcionario {
	
	static Estoque[] items = new Estoque[10];
	
	public static void cadastrar() {
		for(int i=0; i<10; i++) {
			if (items[i] == null) {
			items[i] = new Estoque(Magica.inteiro("Digite a Quantidade"),
								   Magica.inteiro("Digite o ID do Produto"),
								   new Produto(
								   Magica.texto("Digite o Nome do Produto"),
								   Magica.inteiro("Digite o Tamanho do Produto"),
								   Magica.texto("Digite a cor do Produto"),
								   Magica.texto("Digite a marca do Produto")));
			break;
			}
	}
	}
		
	public static void  consultar() {
		for (int i=0; i<10;i++) {
			if (items[i] == null) {
				System.out.println("Item n�o cadastrado");
				i++;
			}
			System.out.println(items[i].getAll());
	}
	
	
	/**editar;
	excluir;
	consultar;
	**/
	
}
}
/**
 * 
 * int qtde, int id, Produto produto, String nome, int size, String cor, String marca
Magica.inteiro("Digite a Quantidade"),
Magica.inteiro("Digite o ID do Produto"),
Magica.texto("Digite o Nome do Produto"),
Magica.texto("Digite o Tamanho do Produto"),
Magica.texto("Digite o Nome do Produto"),
Magica.texto("Digite a marca do Produto"));
 * 
 * **/
